HTMLCollection.prototype.forEach = function (callback) {
  for (let i = 0; i < this.length; i++) {
    callback(this[i]);
  }
};

function resetButtons() {
  let parentElement = document.body;

  let buttons = parentElement.getElementsByClassName("button");

  buttons.forEach(function (button) {
    button.style.backgroundColor = "silver";
  });
}

function changeColor(button) {
  resetButtons();
  button.style.backgroundColor = "aquamarine";
}

let buttons = document.getElementsByClassName("button");
buttons.forEach(function (button) {
  button.addEventListener("click", function () {
    changeColor(this);
  });
});
